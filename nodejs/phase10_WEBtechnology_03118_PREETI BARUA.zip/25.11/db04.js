const mysql = require('mysql2');
const con =mysql.createConnection({
host : 'localhost',
port : 3306,
user : 'root',
password : 'root',
database: 'test'
});

var x= 4;
var y = 'p';
var z='l';

con.connect(function(err) 
{  
 if (err)
    {
			console.log("connection failed" + err);
	}
    else
    {
		
		
				let tql="insert into country (pincode,area,city) values (?,?,?)";
	let vtbfig=[x,y,z];     //fill the values that goes onto the queation marks in the array
	con.query(tql,vtbfig,function(err,rs)
	{

		
		
		if(err)
			
			{
				console.log("insert failed");
			}
			else{
				
				let y= rs.affectedRows;
				console.log("y is not important during insert ,but during update it is important"+y);
			
			}
	});
	  console.log("connection succeded");
	
	}
});






