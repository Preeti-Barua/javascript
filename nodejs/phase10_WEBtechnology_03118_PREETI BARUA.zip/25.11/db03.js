const mysql = require('mysql2');
const con =mysql.createConnection({
host : 'localhost',
port : 3306,
user : 'root',
password : 'root',
database: 'test'
});

var x=2;


con.connect(function(err) 
{   if (err)
    {
			console.log("connection failed" + err);
	}
    else
    {
		
		
			console.log("connection succeded");
			let tql="select pincode,area,city from country ";
			// where pincode=?
			let vtbfig=[];     //fill the values that goes onto the queation marks in the array
	
	con.query(tql,vtbfig,function(err,rs)
	{ 
		
		
		if(err)
			
			{
				console.log("Update failed");
			}
			else{
				
				
				if(rs.length === 0)
						console.log("no item found with the id"+ x);
					else
						for(let z=0; z<rs.length ; z++)
						console.log(rs[z].pincode +"   "+ rs[z].area +"   "+ rs[z].city + "\n");
					
				
			
			}
	});
	
	}
});






