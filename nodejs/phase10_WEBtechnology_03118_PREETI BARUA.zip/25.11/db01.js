const mysql = require('mysql2');
const con =mysql.createConnection({
host : 'localhost',
port : 3306,
user : 'root',
password : 'root',
database: 'test'
});

var x= 'B';
var y = 1;

con.connect(function(err) 
{   if (err)
    {
			console.log("connection failed" + err);
	}
    else
    {
		
		
			console.log("connection succeded");
			// let tql="update country set area=? where pincode=?";
			let tql="delete from country where pincode=?";
	//let vtbfig=[x,y];     //fill the values that goes onto the queation marks in the array
		let vtbfig=[y];
	con.query(tql,vtbfig,function(err,rs)
	{ 
		
		
		if(err)
			
			{
				console.log("Update failed");
			}
			else{
				
				let y= rs.affectedRows;
				//console.log("Updated Rows...... :- --"+y);
				console.log("Deleted Rows...... :- --"+y);
			
			}
	});
	
	}
});






