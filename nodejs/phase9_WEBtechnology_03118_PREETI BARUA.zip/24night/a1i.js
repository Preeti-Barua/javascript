console.log(2);

const express = require('express');
const app = express();

//below two lines are required in your code.
//to process post based requests..

const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static('./xyz'));



  app.post("/ac",function(req,res){ 

  let a = req.body.x;//reading the parametr
//from the request.


let z=0;

  if(a === "3m")
{
	
	 z=req.body.w*3;
	//res.send(z);
}
  else if(a === "4m")
{
	
	 z=req.body.w*4;
	// res.send(z);
}
	res.send("result=" + z);


});
app.listen(1000,function(){console.log('server is running')});