console.log(2);

const express = require('express');
const app = express();

//below two lines are required in your code.
//to process post based requests..
const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static('./xyz'));

app.get("/tuc",function(req,res){ 

let x = req.query.ss;//reading the parametr
//from the request.
x=x.toUpperCase();


res.send(x);


});


app.post("/tuc1",function(req,res){ 

	let y=req.body.kk;
	y=y.toLowerCase();
	res.send(y);

	}
	


);
app.listen(5000,function(){console.log('server is running')});