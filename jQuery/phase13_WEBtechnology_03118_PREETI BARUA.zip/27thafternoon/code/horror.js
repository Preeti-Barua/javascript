const express = require('express');
const app = express();



app.use(express.static('./abc'));

const mysql = require('mysql2');
const con = mysql.createConnection({
  host: 'localhost',
  port:3309,
  user: 'root',
  password:'1234',
  database: 'test'
});


const bodyParser = require('body-parser');//get the object
app.use(bodyParser.urlencoded({ extended: true }));

app.get("/getitemdetailsbasedonitemno",function(req,res){
	
	let x = req.query.ino;
	console.log("input " + x);
	let y ={itemno:0,itemname:"",price:0};//mock value or dummy value.
	let sql ="select itemno, price , itemname from item where itemno=?";
	let vtbfiq=[x];//it is a textbovalue.
		
	con.query(sql,vtbfiq,function(err,neverkeepx)
		{
			if(err) { console.log("select failed" + err); }
			else {
					
					if(neverkeepx.length === 0)
						res.send(y);//we are sending the response from this function
					else
						res.send(neverkeepx[0]);//send the response here
					
							
			}
			
		});
		
		
			
	}
);





app.post("/updateitem",function(req,res){
	
	
	let msg =req.body.xno  +  "  " + req.body.xname +  " " + 
	req.body.xprice; 
	console.log("input is" +  msg)
	let ddbs={status:-1,reason:"db failure"};
		
	//let me copy paste below here..
	

		let sql ="update item set price=?,itemname=? where itemno=?";
		let vtbfiq=[req.body.xprice,req.body.xname,req.body.xno];//fill the values that goes into question mark
		//in an array.
		con.query(sql,vtbfiq,function(err,neverkeepx)
		{
			if(err) { res.send(ddbs); }
			else {
					let y = neverkeepx.affectedRows;
					console.log("affected rows value" + neverkeepx.affectedRows );
					if( y === 0)
					{
						ddbs.status=0;
						ddbs.reason="where condtion failed";
						
						
					}
					 else
					 {
						 
						 ddbs.status=1;
						ddbs.reason="success";
						 
					 }
					 res.send(ddbs);
						  
				
				
			}
			
		});
		
		
			
	}
);



app.listen(600,function(){console.log('server is walking');});
