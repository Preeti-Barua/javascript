const express = require('express');
const app = express();


//get is an event in  http protocol.
app.get("/a123",function(req,res)
{
		res.send("hello");
});

app.get("/b123",function(req,res)
{
		res.send("hi");
		
});



//server is running
app.listen(67,()=>{console.log('go to browser to check');}) ;