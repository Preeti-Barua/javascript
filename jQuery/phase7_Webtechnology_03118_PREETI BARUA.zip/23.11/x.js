console.log(123);

var q = require("./y.js");
console.log(q.f3());