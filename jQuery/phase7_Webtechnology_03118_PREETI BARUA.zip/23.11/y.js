exports.f3=function()
{
	console.log("hello");
	
}