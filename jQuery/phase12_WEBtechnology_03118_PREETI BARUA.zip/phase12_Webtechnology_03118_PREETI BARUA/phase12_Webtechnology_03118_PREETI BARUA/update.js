
const express = require('express');
const app = express();


const mysql = require('mysql2');
const con = mysql.createConnection({
  host: 'localhost',
  port:3306,
  user: 'root',
  password:'root',
  database: 'test'
});



app.use(express.static('./abc'));



const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true })); //call the function of object

app.post("/updateitem",function(req,res){
	
	
	let msg =req.body.xpincode  +  "  " + req.body.xarea +  " " + 
	req.body.xcity; 
	console.log("input is" +  msg)
	let ddbs={status:-1,reason:"db failure"};
		
	
	

		let sql ="update item set area=?,city=? where pincode=?";
		let vtbfiq=[req.body.xarea,req.body.xcity,req.body.xpincode];//fill the values that goes into question mark
		//in an array.
		con.query(sql,vtbfiq,function(err,neverkeepx)
		{
			if(err) { res.send(ddbs); }
			else {
					let y = neverkeepx.affectedRows;
					console.log("affected rows value" + neverkeepx.affectedRows );
					if( y === 0)
					{
						ddbs.status=0;
						ddbs.reason="where condtion failed";
						
						
					}
					 else
					 {
						 
						 ddbs.status=1;
						ddbs.reason="success";
						 
					 }
					 res.send(ddbs);
						  
				
				
			}
			
		});
		
		
			
	}
);

app.listen(900,function(){console.log('server is walking');});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
