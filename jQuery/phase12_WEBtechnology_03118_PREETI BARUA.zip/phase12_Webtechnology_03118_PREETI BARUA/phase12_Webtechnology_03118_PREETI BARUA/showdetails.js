
const express = require('express');
const app = express();


const mysql = require('mysql2');
const con = mysql.createConnection({
  host: 'localhost',
  port:3306,
  user: 'root',
  password:'root',
  database: 'test'
});



app.use(express.static('./abc'));




const bodyParser = require('body-parser');//get the object
app.use(bodyParser.urlencoded({ extended: true }));

app.get("/getitemdetailsbasedonitemno",function(req,res){
	
	let x = req.query.xno;
	console.log("input " + x);
	let y ={itemno:0,itemname:"",price:0};//mock value or dummy value.
	let sql ="select itemno, price , itemname from item where itemno=?";
	let vtbfiq=[x];//it is a textbovalue.
		
	con.query(sql,vtbfiq,function(err,neverkeepx)
		{
			if(err) { console.log("select failed" + err); }
			else {
					
					if(neverkeepx.length === 0)
						res.send(y);//we are sending the response from this function
					else
						res.send(neverkeepx[0]);//send the response here
					
							
			}
			
		});
		
		
			
	}
);

	
app.listen(8000,function(){console.log('server is walking');});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
