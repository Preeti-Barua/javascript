
const express = require('express');
const app = express();


const mysql = require('mysql2');
const con = mysql.createConnection({
  host: 'localhost',
  port:3306,
  user: 'root',
  password:'root',
  database: 'test'
});
var x=22;
var y='sadar';
var z='betul';
app.use(express.static('./abc'));
//below two lines are required in your code.
//to process post based requests.
const bodyParser = require('body-parser');//get the object
app.use(bodyParser.urlencoded({ extended: true })); 
//app.get("/getitemdetailsbasedonitemno",function(req,res){
	con.connect(function(err) 
{   if (err)
    {
			console.log("connection failed" + err);
	}
    else
    {
		let sql ="insert into country(pincode,area,city)values (?,?,?)";
		let vtbfiq=[x,y,z];//it is a textbovalue.
		
		con.query(sql,vtbfiq,function(err,neverkeepx)
		{
			if(err) { console.log("insert failed" + err); }
			else {
					let y = neverkeepx.affectedRows;
					console.log("DATA IS INSERTED" );
				
				
			}
			
		});
		
		
			
	}
});

app.listen(600,function(){console.log('server is walking');});