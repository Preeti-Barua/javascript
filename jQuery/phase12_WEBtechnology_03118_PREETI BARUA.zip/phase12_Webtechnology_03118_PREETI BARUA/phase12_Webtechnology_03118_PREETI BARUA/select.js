
const express = require('express');
const app = express();


const mysql = require('mysql2');
const con = mysql.createConnection({
  host: 'localhost',
  port:3306,
  user: 'root',
  password:'root',
  database: 'test'
});



app.use(express.static('./abc'));

const bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true })); 




app.get("/repeitionisimportant",function(req,res){
	
	
	let msg =req.query.xpincode; 
	console.log("input is" +  msg)
	let ddbs={status:0,content:[]};
		
	
	con.connect(function(err) 
{   if (err)
    {
			console.log("connection failed" + err);
	}
    else
    {
		let sql ="select pincode , area from country where pincode= ?";
		let vtbfiq=[req.query.xpincode];
		con.query(sql,vtbfiq,function(err,neverkeepx)
		{
			if(err) { console.log("select failed" + err); }
			else {
					
					if(neverkeepx.length === 0)
					{
						res.send(ddbs);
						
						
					}
					else
					{
						ddbs.status=1;
						ddbs.content=neverkeepx;
						res.send(ddbs);
					}
							
			}
			
		});
		
		
			
	}
});


});
	
app.listen(600,function(){console.log('server is walking')});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
